package GithubDemos.Inheritable;

public class Main2 {
    
    private final static InheritableThreadLocal<String> holder = new InheritableThreadLocal<String>();

    public static void main(String[] args){
        // Define o valor do InheritableThreadLocal na thread principal
        holder.set("aaa");
        // Imprime o valor do InheritableThreadLocal na thread principal
        System.out.println("begin = " + holder.get());

        // Cria e inicia uma nova thread
        Thread a = new Thread(new Runnable(){
            @Override
            public void run() {
                // Imprime o valor do InheritableThreadLocal na thread "a" no início
                System.out.println("thread begin = " + holder.get());
                // Modifica o valor do InheritableThreadLocal na thread "a"
                holder.set("bbb");
                // Imprime o valor modificado do InheritableThreadLocal na thread "a"
                System.out.println("thread ends = " + holder.get());
            }
        });

        a.start();

        try {
            // Pausa a execução da thread principal por 2 segundos
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Imprime o valor do InheritableThreadLocal na thread principal após a pausa
        System.out.println("end = " + holder.get());
    }

}