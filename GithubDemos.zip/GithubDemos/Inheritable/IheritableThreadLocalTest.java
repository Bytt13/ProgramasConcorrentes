package GithubDemos.Inheritable;

public class IheritableThreadLocalTest {
    private static InheritableThreadLocal<StringBuffer> ITL = new InheritableThreadLocal<StringBuffer>() {
        @Override
        protected StringBuffer initialValue() {
            return new StringBuffer("Hello");
        }
    };

    public static void main(String[] args){
        // Imprime o valor inicial do InheritableThreadLocal na thread principal
        System.out.println(Thread.currentThread().getName() + " " + ITL.get());

        // Cria e inicia uma nova thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                // Imprime o valor do InheritableThreadLocal na thread "inner"
                System.out.println(Thread.currentThread().getName() + " " + ITL.get());

                // Cria e inicia uma nova thread dentro da thread "inner"
                new Thread(new Runnable() {
                    @Override
                    public void run(){
                        // Imprime o valor do InheritableThreadLocal na thread "inner-inner"
                        System.out.println(Thread.currentThread().getName() + " " + ITL.get());
                        // Modifica o valor do InheritableThreadLocal na thread "inner-inner"
                        ITL.get().append(" World");
                        // Imprime o valor modificado do InheritableThreadLocal na thread "inner-inner"
                        System.out.println(Thread.currentThread().getName() + " " + ITL.get());
                    }
                }, "inner-inner").start();

                try {
                    // Pausa a execução da thread "inner" por 1 segundo
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // Imprime o valor do InheritableThreadLocal na thread "inner" após a pausa
                System.out.println(Thread.currentThread().getName() + " " + ITL.get());
            }
        }, "inner").start();

        try {
            // Pausa a execução da thread principal por 1 segundo
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
