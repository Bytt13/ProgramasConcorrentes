package GithubDemos.Inheritable;

/**
 * A classe ThreadLocalTest demonstra o uso de ThreadLocal em Java.
 * Cada thread terá seu próprio valor isolado das variáveis tl_1 e tl_2.
 */
public class ThreadLocalTest {
    
    /**
     * ThreadLocal tl_1 armazena uma string com o nome da thread atual.
     */
    private static ThreadLocal<String> tl_1 = new ThreadLocal<String>(){
        @Override
        protected String initialValue() {
            return "Thread name: " + Thread.currentThread().getName();
        }
    };

    /**
     * ThreadLocal tl_2 armazena outra string com o nome da thread atual,
     * porém com um formato ligeiramente diferente.
     */
    private static ThreadLocal<String> tl_2 = new ThreadLocal<String>() {
        @Override
        protected String initialValue() {
            return "Thread name 2 : " + Thread.currentThread().getName();
        }
    };
    
    /**
     * Método principal que inicia 10 threads, cada uma executando a função prt().
     * Cada thread criará sua própria instância de ThreadLocalTest.
     */
    public static void main(String[] args) {
        for(int i = 0; i < 10; i++){
            new Thread(new Runnable(){
                @Override
                public void run() {
                    new ThreadLocalTest().prt();
                }
            }).start();
        }
    }

    /**
     * Método prt imprime os valores armazenados nos ThreadLocals tl_1 e tl_2
     * para a thread atual.
     */
    public void prt(){
        System.out.println(tl_1.get());
        System.out.println(tl_2.get());
    }
}
