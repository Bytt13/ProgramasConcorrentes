package GithubDemos.Inheritable;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    public static void main(String[] args){
        // Cria uma instância de ThreadLocal
        final ThreadLocal<String> t1 = new ThreadLocal<String>();
        t1.set("ThreadLocal-VAL");
        // Imprime o valor do ThreadLocal na thread principal
        System.out.println("Main Thread-1: " + t1.get());

        // Cria e inicia uma nova thread que imprime o valor do ThreadLocal
        new Thread(){
            @Override
            public void run(){
                System.out.println("Child Thread: " + t1.get());
            }
        }.start();

        // Cria e inicia uma instância da classe Sub que imprime o valor do ThreadLocal
        Sub sub = new Sub(t1);
        sub.start();

        // Cria uma instância de InheritableThreadLocal
        final InheritableThreadLocal<String> it1 = new InheritableThreadLocal<String>();
        it1.set("InheritableThreadLocal-VAL");
        // Imprime o valor do InheritableThreadLocal na thread principal
        System.out.println("Main Thread-2: " + it1.get());

        // Cria e inicia uma nova thread que imprime o valor do InheritableThreadLocal
        new Thread(){
            @Override
            public void run(){
                System.out.println("Child Thread: " + it1.get());
            }
        }.start();

        // Cria e inicia uma instância da classe Sub que imprime o valor do InheritableThreadLocal
        Sub sub2 = new Sub(it1);
        sub2.start();
    }

    /**
     * A classe Sub estende a classe Thread e imprime o valor de um ThreadLocal.
     */
    static class Sub extends Thread{
        ThreadLocal<String> t1;

        /**
         * Construtor da classe Sub.
         * 
         * @param t1 O ThreadLocal cujo valor será impresso.
         */
        public Sub (ThreadLocal<String> t1){
            this.t1 = t1;
        }

        /**
         * O método run é executado quando a thread é iniciada.
         * Ele imprime o valor do ThreadLocal.
         */
        @Override
        public void run(){
            System.out.println("Sub Thread: " + t1.get());
        }
    }
}
