package GithubDemos.Arrange;

/**
 * A classe TicketOffice2 implementa a interface Runnable e simula a venda e devolução de ingressos em um cinema.
 */
public class TicketOffice2 implements Runnable{
    
    private Cinema cinema;

    /**
     * Construtor da classe TicketOffice2.
     * 
     * @param cinema A instância de Cinema onde os ingressos serão vendidos e devolvidos.
     */
    public TicketOffice2(Cinema cinema){
        this.cinema = cinema;
    }

    @Override
    public void run(){
        cinema.sellTickets2(2);
        cinema.sellTickets2(4);
        cinema.sellTickets1(2);
        cinema.sellTickets1(1);
        cinema.returnTickets2(2);
        cinema.sellTickets1(3);
        cinema.sellTickets1(2);
        cinema.sellTickets2(2);
    }
}
