package GithubDemos.Daemon;

import java.util.Date;
import java.util.Deque;

/**
 * A classe CleanerTask estende a classe Thread e implementa uma tarefa que limpa eventos antigos de uma fila.
 */
public class CleanerTask extends Thread {
    private Deque<Event> deque;

    /**
     * Construtor da classe CleanerTask.
     * 
     * @param deque A fila de eventos a ser limpa.
     */
    public CleanerTask(Deque<Event> deque) {
        this.deque = deque;
        setDaemon(true); // Define a thread como uma thread daemon
    }

    /**
     * O método run é executado quando a thread é iniciada.
     * Ele chama o método clean periodicamente para limpar eventos antigos da fila.
     */
    @Override
    public void run() {
        while (true) {
            Date date = new Date();
            clean(date);
        }
    }

    /**
     * O método clean remove eventos da fila que são mais antigos do que 10 segundos.
     * 
     * @param date A data atual usada para calcular a diferença de tempo.
     */
    private void clean(Date date) {
        long difference;
        boolean delete;

        if (deque.size() == 0) {
            return;
        }

        delete = false;

        do {
            Event e = deque.getLast();
            difference = date.getTime() - e.getDate().getTime();
            if (difference > 10000) {
                System.out.println(String.valueOf(new Date()) + " Cleaner: " + e.getEvent());
                deque.removeLast();
                delete = true;
            }
        } while (difference > 10000 && !deque.isEmpty());

        if (delete) {
            System.out.println("Cleaner: Size of the queue: " + deque.size());
        }
    }
}
