package GithubDemos.Daemon;

import java.util.Date;
import java.util.Deque;
import java.util.concurrent.TimeUnit;

/**
 * A classe WriterTask implementa a interface Runnable e simula a geração de eventos.
 */
public class WriterTask implements Runnable {

    private Deque<Event> deque;

    /**
     * Construtor da classe WriterTask.
     * 
     * @param deque A fila de eventos onde os eventos gerados serão adicionados.
     */
    public WriterTask(Deque<Event> deque) {
        this.deque = deque;
    }
    
    /**
     * O método run é executado quando a thread é iniciada.
     * Ele gera eventos e os adiciona à fila de eventos.
     */
    @Override
    public void run() {
        for (int i = 0; i < 100; i++) {
            // Cria um novo evento
            Event event = new Event();
            event.setDate(new Date());
            event.setEvent(String.format("The thread %s has generated an event => %s",
                Thread.currentThread().getId(), String.valueOf(event.getDate())));

            // Adiciona o evento à frente da fila
            deque.addFirst(event);

            try {
                // Pausa a execução por 1 segundo
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                // Imprime a stack trace se a thread for interrompida
                e.printStackTrace();
            }
        }
    }
}
