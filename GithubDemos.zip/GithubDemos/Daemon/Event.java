package GithubDemos.Daemon;

import java.util.Date;

/**
 * A classe Event representa um evento com uma data e uma descrição.
 */
public class Event {
    private Date date;
    private String event;

    /**
     * Retorna a data do evento.
     * 
     * @return A data do evento.
     */
    public Date getDate() {
        return date;
    }

    /**
     * Define a data do evento.
     * 
     * @param date A data do evento.
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Define a descrição do evento.
     * 
     * @param event A descrição do evento.
     */
    public void setEvent(String event) {
        this.event = event;
    }

    /**
     * Retorna a descrição do evento.
     * 
     * @return A descrição do evento.
     */
    public String getEvent() {
        return event;
    }
}
