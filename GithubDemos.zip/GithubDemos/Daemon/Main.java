package GithubDemos.Daemon;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    
    public static void main(String[] args){
        // Cria uma fila de eventos
        Deque<Event> deque = new ArrayDeque<Event>();

        // Cria uma instância de WriterTask e inicia 3 threads para executar a tarefa
        WriterTask writer = new WriterTask(deque);
        for(int i = 0; i < 3; i++){
            Thread thread = new Thread(writer);
            thread.start();
        }

        // Cria uma instância de CleanerTask e inicia a thread para executar a tarefa
        CleanerTask cleaner = new CleanerTask(deque);
        cleaner.start();

        // Loop infinito para monitorar o tamanho da fila a cada 5 segundos
        while (true) {
            try {
                // Pausa a execução do método main por 5 segundos
                Thread.sleep(5000);
                // Imprime o tamanho atual da fila
                System.out.println("Main: Size of the queue: " + deque.size());
            } catch (InterruptedException e) {
                // Imprime a stack trace se a thread for interrompida
                e.printStackTrace();
            }
        }
    }
}
