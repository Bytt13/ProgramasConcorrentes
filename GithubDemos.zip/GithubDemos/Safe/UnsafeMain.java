package GithubDemos.Safe;

import java.util.concurrent.TimeUnit;

/**
 * A classe UnsafeMain contém o método principal que inicia a execução do programa.
 */
public class UnsafeMain {
    public static void main(String[] args){
        // Cria uma instância de UnsafeTask
        UnsafeTask task = new UnsafeTask();

        // Cria e inicia 3 threads para executar a tarefa
        for(int i = 0; i < 3; i++){
            Thread thread = new Thread(task);
            thread.start();

            try{
                // Pausa a execução do método main por 2 segundos
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e){
                // Imprime a stack trace se a thread for interrompida
                e.printStackTrace();
            }
        }
    }
}
