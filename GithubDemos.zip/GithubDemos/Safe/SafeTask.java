package GithubDemos.Safe;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * A classe SafeTask implementa a interface Runnable e usa ThreadLocal para armazenar a data de início de cada thread.
 */
public class SafeTask implements Runnable {

    // ThreadLocal para armazenar a data de início de cada thread
    private final static ThreadLocal<Date> threadLocal = new ThreadLocal<Date>() {
        @Override
        protected Date initialValue() {
            return new Date();
        }
    };

    @Override
    public void run() {
        // Imprime a data de início da thread
        System.out.println("Thread: " + Thread.currentThread().getId() + " Start Time: " + threadLocal.get());
        try {
            // Pausa a execução da thread por 2 segundos
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }
        // Imprime a data de término da thread
        System.out.println("Thread: " + Thread.currentThread().getId() + " End Time: " + threadLocal.get());
    }
}