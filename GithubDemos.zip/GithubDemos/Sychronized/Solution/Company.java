package GithubDemos.Sychronized.Solution;

/**
 * A classe Company implementa a interface Runnable e simula a adição de valores a uma conta bancária.
 */
public class Company implements Runnable {
    
    private Account account;

    /**
     * Construtor da classe Company.
     * 
     * @param account A instância de Account onde os valores serão adicionados.
     */
    public Company(Account account){
        this.account = account;
    }

    @Override
    public void run(){
        for(int i = 0; i < 100; i++){
            // Adiciona 1000 ao saldo da conta
            account.addAmount(1000);
        }
    }
}