package GithubDemos.Sychronized.Solution;

public class Main {
    
    public static void main(String[] args){
        // Cria uma instância de Account e define o saldo inicial
        Account account = new Account();
        account.setBalance(1000);

        // Cria uma instância de Company e uma thread para executá-la
        Company company = new Company(account);
        Thread companyThread = new Thread(company);

        // Cria uma instância de Bank e uma thread para executá-la
        Bank bank = new Bank(account);
        Thread bankThread = new Thread(bank);

        // Imprime o saldo inicial da conta
        System.out.println("Account : Initial Balance: " + account.getBalance());

        // Inicia as threads da empresa e do banco
        companyThread.start();
        bankThread.start();

        try {
            // Aguarda a conclusão das threads
            companyThread.join();
            bankThread.join();
            // Imprime o saldo final da conta
            System.out.println("Account : Final Balance: " + account.getBalance());
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }
    }
}