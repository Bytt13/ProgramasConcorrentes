package GithubDemos.Lock;

/**
 * A classe Job implementa a interface Runnable e simula um trabalho de impressão.
 */
public class Job implements Runnable{
    
    private PrintQueue printQueue;

    /**
     * Construtor da classe Job.
     * 
     * @param printQueue A instância de PrintQueue usada para imprimir o trabalho.
     */
    public Job(PrintQueue printQueue){
        this.printQueue = printQueue;
    }

    @Override
    public void run() {
        // Simula a impressão de um trabalho
        printQueue.printJob(new Object());
    }
}
