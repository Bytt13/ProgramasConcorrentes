package GithubDemos.Lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Classe que demonstra o uso de ReentrantLock para controle de concorrência entre threads.
 */
public class ReentrantingLockTest {
    
    // Lock reentrante para controle de acesso entre threads
    final Lock lock = new ReentrantLock();

    /**
     * Método principal que inicia duas threads concorrentes e manipula locks.
     */
    public static void main(String[] args) throws InterruptedException {
        ReentrantingLockTest r = new ReentrantingLockTest();

        // Criação de duas threads que executam a mesma tarefa
        Thread t1 = new Thread(r.createTask(), "Thread 1");
        Thread t2 = new Thread(r.createTask(), "Thread 2");

        // Início das threads
        t1.start(); 
        t2.start();

        // Aguarda 600ms e interrompe a segunda thread
        Thread.sleep(600);
        t2.interrupt();
        
        // Aguarda 10 segundos antes de encerrar o programa
        Thread.sleep(10000);
    }

    /**
     * Método que cria uma tarefa para ser executada por múltiplas threads.
     * A tarefa tenta adquirir o lock e executa um bloco crítico.
     */
    private Runnable createTask() {
        return new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        // Tenta adquirir o lock dentro de 500ms
                        if (lock.tryLock(500, TimeUnit.MILLISECONDS)) {
                            try {
                                System.out.println("Thread " + Thread.currentThread().getName() + " Locked");
                                Thread.sleep(1000); // Simula processamento dentro do lock
                            } finally {
                                // Libera o lock após processamento
                                lock.unlock();
                                System.out.println("Thread " + Thread.currentThread().getName() + " Unlocked");
                            }
                            break;
                        } else {
                            System.out.println("Thread " + Thread.currentThread().getName() + " was not able to lock");
                        }
                    } catch (InterruptedException e) {
                        // Captura interrupção da thread e exibe mensagem
                        System.out.println("Thread " + Thread.currentThread().getName() + " interrupted");
                        e.printStackTrace();
                        return;
                    }
                }
            }
        };
    }
}