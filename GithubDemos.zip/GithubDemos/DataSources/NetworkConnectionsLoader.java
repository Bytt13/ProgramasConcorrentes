package GithubDemos.DataSources;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * A classe NetworkConnectionsLoader implementa a interface Runnable e simula o carregamento de conexões de rede.
 */
public class NetworkConnectionsLoader implements Runnable {
    
    /**
     * O método run é executado quando a thread é iniciada.
     * Ele simula o carregamento de conexões de rede, pausando a execução por 4 segundos.
     */
    @Override
    public void run() {
        // Imprime a mensagem de início do carregamento de conexões de rede com a data e hora atual
        System.out.println("Beginning network connections loading: " + new Date());

        try {
            // Pausa a execução por 4 segundos para simular o carregamento de conexões de rede
            TimeUnit.SECONDS.sleep(4);
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }

        // Imprime a mensagem de término do carregamento de conexões de rede com a data e hora atual
        System.out.println("Network connections loading has finished: " + new Date());
    }
}
