package GithubDemos.DataSources;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * A classe DataSourcesLoader implementa a interface Runnable e simula o carregamento de fontes de dados.
 */
public class DataSourcesLoader implements Runnable {
    
    /**
     * O método run é executado quando a thread é iniciada.
     * Ele simula o carregamento de fontes de dados, pausando a execução por 6 segundos.
     */
    @Override
    public void run() {
        // Imprime a mensagem de início do carregamento de fontes de dados com a data e hora atual
        System.out.println("Beginning data sources loading: " + new Date());

        try {
            // Pausa a execução por 6 segundos para simular o carregamento de fontes de dados
            TimeUnit.SECONDS.sleep(6);
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }

        // Imprime a mensagem de término do carregamento de fontes de dados com a data e hora atual
        System.out.println("Data sources loading has finished: " + new Date());
    }
}
