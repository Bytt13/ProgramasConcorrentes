package GithubDemos.DataSources;

import java.util.Date;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {

    public static void main(String[] args){
        // Cria uma instância de DataSourcesLoader
        DataSourcesLoader dsLoader = new DataSourcesLoader();
        // Cria uma nova thread para executar o DataSourcesLoader
        Thread t1 = new Thread(dsLoader, "DataSourceThread");
        // Inicia a thread
        t1.start();

        // Cria uma instância de NetworkConnectionsLoader
        NetworkConnectionsLoader ncLoader = new NetworkConnectionsLoader();
        // Cria uma nova thread para executar o NetworkConnectionsLoader
        Thread t2 = new Thread(ncLoader, "NetworkConnectionLoader");
        // Inicia a thread
        t2.start();

        try {
            // Aguarda a conclusão da thread t1
            t1.join();
            // Aguarda a conclusão da thread t2
            t2.join();
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }

        // Imprime a mensagem indicando que a configuração foi carregada com a data e hora atual
        System.out.println("Main: Configuration has been loaded: " + new Date());
    }
}
