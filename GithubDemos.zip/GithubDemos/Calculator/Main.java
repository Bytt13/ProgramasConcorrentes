package GithubDemos.Calculator;

import java.io.IOException;
import java.lang.Thread.State;

public class Main {
    
    public static void main(String[] args) throws IOException{
        System.out.println("Minimum priority: " + Thread.MIN_PRIORITY);
        System.out.println("Normal priority: " + Thread.NORM_PRIORITY);
        System.out.println("Maximum priority: " + Thread.MAX_PRIORITY);

        Thread threads[];
        Thread.State status[];
        
        threads = new Thread[10];
        status = new Thread.State[10];

        for(int i = 0; i < 10; i++){
            threads[i] = new Thread(new Calculator(i));
            if(i % 2 == 0){
                threads[i].setPriority(Thread.MAX_PRIORITY);
            } else {
                threads[i].setPriority(Thread.MIN_PRIORITY);
            }
            threads[i].setName("Thread: "+ i);
        }

        for(int i = 0; i < 10; i++){
            System.out.println("Main : Status of Thread " + i + " : " + threads[i].getState());
            status[i] = threads[i].getState();
        }
   
        for(int i = 0; i < 10; i++){
            threads[i].start();
        }
   
        boolean finish = false;
        while(!finish){
            for(int i= 0; i< 10; i++){
                if(threads[i].getState() != status[i]){
                    status[i] = threads[i].getState();
                }
            }
            
            finish = true;
            for(int i = 0; i < 10; i++){
                finish = finish && (threads[i].getState() == State.TERMINATED);
            }
        }
    }
}
