package GithubDemos.Calculator;

public class ThreadStatus extends Thread{
    
    public ThreadStatus(){
        super("ThreadStatus");
    }

    @Override
    public void run(){
        for(int i = 0; i < 5; i++){
            System.out.println(Thread.currentThread().getState() + " => " + i);
        }
    }

    public static void main(String[] args) throws InterruptedException{
        ThreadStatus t = new ThreadStatus();
        System.out.println(t.getState());

        t.start();
        t.join();

        System.out.println("end");
        System.out.println(t.getState());
    }
}
