package GithubDemos.ThreadFactory;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    
    public static void main(String[] args){
        // Cria uma instância de MyThreadFactory com o nome "MyThreadFactory"
        MyThreadFactory threadFactory = new MyThreadFactory("MyThreadFactory");
        // Cria uma instância de Task
        Task task = new Task();
        Thread thread;

        System.out.println("Starting the threads");

        // Cria e inicia 5 threads usando a fábrica de threads
        for(int i = 0; i < 5; i++){
            thread = threadFactory.newThread(task);
            thread.start();
        }

        // Imprime as estatísticas da fábrica de threads
        System.out.println("Factory stats:");
        System.out.println(threadFactory.getStats());
    }
}
