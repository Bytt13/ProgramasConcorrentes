package GithubDemos.PrimeGenerator;

public class PrimeGenerator extends Thread{
    
    @Override
    public void run(){
        long number = 1L;

        while(true){
            if(isPrime(number)){
                System.out.println("o numero " + number + " eh primo");
            }

            if(isInterrupted()){
                System.out.println("status do programa: " + getState());
                System.out.println("prime generator foi interrompido");
                return;
            }

            number++;
        }
    }

    private boolean isPrime(long number){
        if(number < 2){
            return false;
        }
        for(long i = 2; i < number; i++){
            if(number % i == 0){
                return false;
            }
        }
        return true;
    }
}
