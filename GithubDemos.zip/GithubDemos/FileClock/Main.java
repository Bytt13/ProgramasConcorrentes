package GithubDemos.FileClock;

import java.util.concurrent.TimeUnit;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    public static void main(String[] args) {
        // Cria uma instância de FileClock
        FileClock clock = new FileClock();
        
        // Cria uma nova thread para executar o FileClock
        Thread thread = new Thread(clock);

        // Inicia a thread
        thread.start();

        try {
            // Pausa a execução do método main por 5 segundos
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }

        // Interrompe a execução da thread FileClock
        thread.interrupt();
    }
}
