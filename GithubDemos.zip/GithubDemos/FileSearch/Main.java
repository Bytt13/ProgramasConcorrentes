package GithubDemos.FileSearch;

import java.util.concurrent.TimeUnit;

public class Main {
    
    public static void main(String[] args){
        FileSearch searcher = new FileSearch("'/Users/lucas/Documents/UESB - TEXTOS/MER'","Atividade01BD");
        Thread t = new Thread(searcher);

        t.start();

        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        t.interrupt();
    }
}
