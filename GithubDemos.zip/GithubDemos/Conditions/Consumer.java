package GithubDemos.Conditions;

/**
 * A classe Consumer implementa a interface Runnable e consome eventos de um armazenamento de eventos.
 */
public class Consumer implements Runnable{
    
    private EventStorage storage;
    
    /**
     * Construtor da classe Consumer.
     * 
     * @param storage A instância de EventStorage de onde os eventos serão consumidos.
     */
    public Consumer(EventStorage storage){
        this.storage = storage;
    }
    
    @Override
    public void run(){
        for(int i = 0; i < 100; i++){
            // Consome um evento do armazenamento de eventos
            storage.get();
        }
    }
}
