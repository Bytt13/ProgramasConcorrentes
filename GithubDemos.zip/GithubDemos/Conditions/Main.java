package GithubDemos.Conditions;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    
    public static void main(String[] args){
        // Cria uma instância de EventStorage
        EventStorage storage = new EventStorage();

        // Cria uma instância de Producer e uma thread para executá-lo
        Producer producer = new Producer(storage);
        Thread producerThread = new Thread(producer);

        // Cria uma instância de Consumer e uma thread para executá-lo
        Consumer consumer = new Consumer(storage);
        Thread consumerThread = new Thread(consumer);

        // Inicia as threads do produtor e do consumidor
        consumerThread.start();
        producerThread.start();
    }
}
