package GithubDemos.UncheckedException;

import java.lang.Thread.UncaughtExceptionHandler;

/**
 * A classe ExceptionHandler implementa a interface UncaughtExceptionHandler e lida com exceções não capturadas em threads.
 */
public class ExceptionHandler implements UncaughtExceptionHandler {
    
    /**
     * O método uncaughtException é chamado quando uma thread termina devido a uma exceção não capturada.
     * 
     * @param t A thread que gerou a exceção.
     * @param e A exceção não capturada.
     */
    @Override
    public void uncaughtException(Thread t, Throwable e) {
        System.out.printf("An exception has been captured\n");
        System.out.printf("Thread: %s\n", t.getId());
        System.out.printf("Exception: %s: %s\n", e.getClass().getName(), e.getMessage());
        System.out.printf("Stack Trace: \n");
        e.printStackTrace(System.out);
        System.out.printf("Thread status: %s\n", t.getState());
    }
}
