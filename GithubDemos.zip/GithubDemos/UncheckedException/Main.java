package GithubDemos.UncheckedException;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    public static void main(String[] args){
        // Cria uma instância de Task
        Task task = new Task();
        // Cria uma nova thread para executar a Task
        Thread thread = new Thread(task);
        // Define o ExceptionHandler para lidar com exceções não capturadas na thread
        thread.setUncaughtExceptionHandler(new ExceptionHandler());
        // Inicia a thread
        thread.start();
    }
}
