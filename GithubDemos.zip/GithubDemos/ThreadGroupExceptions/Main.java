package GithubDemos.ThreadGroupExceptions;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    public static void main(String[] args){
        // Cria um grupo de threads chamado "MyThreadGroup"
        MyThreadGroup threadGroup = new MyThreadGroup("MyThreadGroup");
        // Cria uma instância de Task
        Task task = new Task();

        // Cria e inicia 5 threads no grupo de threads "MyThreadGroup"
        for(int i = 0; i < 5; i++){
            Thread thread = new Thread(threadGroup, task);
            thread.start();
        }
    }
}
