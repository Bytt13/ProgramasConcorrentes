package GithubDemos.ThreadGroup;

import java.util.concurrent.TimeUnit;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    
    public static void main(String[] args){
        // Cria um grupo de threads chamado "Searcher"
        ThreadGroup threadGroup = new ThreadGroup("Searcher");
        // Cria uma instância de Result para armazenar o resultado da busca
        Result result = new Result();

        // Cria uma instância de SearchTask e inicia 5 threads para executar a tarefa
        SearchTask searchTask = new SearchTask(result);
        for(int i = 0; i < 5; i++){
            Thread thread = new Thread(threadGroup, searchTask);
            thread.start();

            try{
                // Pausa a execução do método main por 1 segundo
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e){
                // Imprime a stack trace se a thread for interrompida
                e.printStackTrace();
            }
        }

        // Imprime o número de threads ativas no grupo de threads
        System.out.println("Active Threads: " + threadGroup.activeCount());
        // Imprime informações sobre o grupo de threads
        System.out.println("Information about the Thread Group");
        threadGroup.list();

        // Cria um array de threads do tamanho do número de threads ativas no grupo
        Thread[] threads = new Thread[threadGroup.activeCount()];
        // Preenche o array com as threads ativas no grupo
        threadGroup.enumerate(threads);

        // Imprime o nome e o estado de cada thread no grupo
        for(int i = 0; i < threadGroup.activeCount(); i++){
            System.out.println("Thread " + threads[i].getName() + " " + threads[i].getState());
        }

        // Espera até que todas as threads no grupo terminem
        waitFinish(threadGroup);

        // Interrompe todas as threads no grupo
        threadGroup.interrupt();
    }

    /**
     * O método waitFinish espera até que todas as threads no grupo terminem.
     * 
     * @param threadGroup O grupo de threads a ser monitorado.
     */
    private static void waitFinish(ThreadGroup threadGroup){
        while(threadGroup.activeCount() > 4){
            try{
                // Pausa a execução por 1 segundo
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e){
                // Imprime a stack trace se a thread for interrompida
                e.printStackTrace();
            }
        }
    }
}
