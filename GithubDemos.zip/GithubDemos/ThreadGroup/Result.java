package GithubDemos.ThreadGroup;

/**
 * A classe Result armazena o resultado de uma busca.
 */
public class Result {
    
    private String name;

    /**
     * Retorna o nome do resultado.
     * 
     * @return O nome do resultado.
     */
    public String getName(){
        return name;
    }

    /**
     * Define o nome do resultado.
     * 
     * @param name O nome do resultado.
     */
    public void setName(String name){
        this.name = name;
    }
}
