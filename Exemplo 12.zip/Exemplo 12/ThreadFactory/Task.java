package GithubDemos.ThreadFactory;

import java.util.concurrent.TimeUnit;

/**
 * A classe Task implementa a interface Runnable e simula uma tarefa que pausa a execução por 1 segundo.
 */
public class Task implements Runnable{
    
    @Override
    public void run(){
        try {
            // Pausa a execução da thread por 1 segundo
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }
    }
}
