package GithubDemos.FileClock;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * A classe FileClock implementa a interface Runnable e simula um relógio que imprime a data e hora atual a cada segundo.
 */
public class FileClock implements Runnable {

    /**
     * O método run é executado quando a thread é iniciada.
     * Ele imprime a data e hora atual a cada segundo, por 10 vezes.
     */
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            // Imprime a data e hora atual
            System.out.println(new Date());
            try {
                // Pausa a execução por 1 segundo
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                // Mensagem exibida se a thread for interrompida
                System.out.println("O FileClock foi interrompido");
                return;
            }
        }
    }
}
