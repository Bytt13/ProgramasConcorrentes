package GithubDemos.Sychronized.Solution;

public class Account {
    
    private double balance;

    /**
     * Retorna o saldo da conta.
     * 
     * @return O saldo da conta.
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Define o saldo da conta.
     * 
     * @param balance O saldo da conta.
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * Adiciona um valor ao saldo da conta de forma sincronizada.
     * 
     * @param amount O valor a ser adicionado ao saldo.
     */
    public synchronized void addAmount(double amount){
        double temp = balance;
        try {
            Thread.sleep(10); // Simula um atraso na operação
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        temp += amount;
        balance = temp;
    }

    /**
     * Subtrai um valor do saldo da conta de forma sincronizada.
     * 
     * @param amount O valor a ser subtraído do saldo.
     */
    public synchronized void subtractAmount(double amount){
        double temp = balance;
        try {
            Thread.sleep(10); // Simula um atraso na operação
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        temp -= amount;
        balance = temp;
    }
}