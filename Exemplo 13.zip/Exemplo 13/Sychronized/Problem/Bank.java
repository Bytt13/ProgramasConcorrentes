package GithubDemos.Sychronized.Problem;

/**
 * A classe Bank implementa a interface Runnable e simula a subtração de valores de uma conta bancária.
 */
public class Bank implements Runnable{

    private Account account;

    /**
     * Construtor da classe Bank.
     * 
     * @param account A instância de Account de onde os valores serão subtraídos.
     */
    public Bank(Account account){
        this.account = account;
    }
    
    @Override 
    public void run(){
        for(int i = 0; i < 100; i++){
            // Subtrai 1000 do saldo da conta
            account.subtractAmount(1000);
        }
    }
}
