package GithubDemos.Sychronized.Problem;

public class Account {
    
    private double balance;

    /**
     * Retorna o saldo da conta.
     * 
     * @return O saldo da conta.
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Define o saldo da conta.
     * 
     * @param balance O saldo da conta.
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * Adiciona um valor ao saldo da conta.
     * Esta função não está sincronizada, o que pode causar problemas de concorrência.
     * 
     * @param amount O valor a ser adicionado ao saldo.
     */
    public void addAmount(double amount){
        double temp = balance;
        try {
            Thread.sleep(10); // Simula um atraso na operação
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        temp += amount;
        balance = temp;
    }

    /**
     * Subtrai um valor do saldo da conta.
     * Esta função não está sincronizada, o que pode causar problemas de concorrência.
     * 
     * @param amount O valor a ser subtraído do saldo.
     */
    public void subtractAmount(double amount){
        double temp = balance;
        try {
            Thread.sleep(10); // Simula um atraso na operação
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        temp -= amount;
        balance = temp;
    }
}
