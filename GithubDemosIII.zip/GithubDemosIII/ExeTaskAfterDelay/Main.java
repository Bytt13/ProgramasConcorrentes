package ExeTaskAfterDelay;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Main {
    /**
     * Método principal que agenda a execução de tarefas com um atraso.
     * 
     * @param args Argumentos da linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        // Cria um ScheduledExecutorService com um pool de threads de tamanho 1
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

        // Imprime a data e hora de início
        System.out.println("Main: Starting at: " + new Date());

        // Agenda 5 tarefas para execução com atrasos incrementais
        for (int i = 0; i < 5; i++) {
            Task task = new Task("Task-" + i);
            // agenda a tarefa com um atraso de i + 1 segundos
            executor.schedule(task, i + 1, TimeUnit.SECONDS);
        }

        // Encerra o executor
        executor.shutdown();

        try {
            // Aguarda a conclusão de todas as tarefas por até 1 dia
            executor.awaitTermination(1, TimeUnit.DAYS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Imprime a data e hora de término
        System.out.println("Core: Ends at: " + new Date());
    }
}
