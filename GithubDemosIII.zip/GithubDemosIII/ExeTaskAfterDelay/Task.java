package ExeTaskAfterDelay;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Callable;

/**
 * Classe que representa uma tarefa que pode ser agendada para execução com atraso.
 * Implementa a interface Callable para que possa ser executada por uma thread.
 */
public class Task implements Callable<String> {
    private final SimpleDateFormat sdf = new SimpleDateFormat("mm:ss.SSS");
    
    private String name;

    /**
     * Construtor da classe.
     * @param name Nome da tarefa.
     */
    public Task(String name) {
        this.name = name;
    }

    @Override
    public String call() throws Exception {
        System.out.println(name + ": Starting at : " + sdf.format(new Date()));
        return "Hello, world";
    }

}
