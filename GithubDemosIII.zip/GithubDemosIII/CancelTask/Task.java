package CancelTask;

import java.util.concurrent.Callable;

/**
 * Classe que representa uma tarefa que pode ser cancelada.
 * Implementa a interface Callable para que possa ser executada por uma thread.
 */
public class Task implements Callable<String> {

    @Override
    public String call() throws Exception {
        while (true) {
            System.out.println("Task: Test");
            Thread.sleep(100);
        }
    }

}
