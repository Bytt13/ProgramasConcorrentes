package CancelTask;

import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Main {
    /**
     * Método principal que executa uma tarefa e a cancela após um tempo.
     * 
     * @param args Argumentos da linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        // Cria um executor com um pool de threads cacheado
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();

        // Cria uma nova tarefa
        Task task = new Task();

        // Informa que a tarefa está sendo executada
        System.out.println("Main: Executando a Tarefa");

        // Submete a tarefa ao executor e obtém um Future para controlar a execução
        Future<String> result = executor.submit(task);

        try {
            // Aguarda 2 segundos antes de cancelar a tarefa
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Cancela a tarefa
        System.out.println("Main: Cancelando a Tarefa");
        result.cancel(true);

        // Verifica se a tarefa foi cancelada e se está concluída
        System.out.println("Main: Cancelada: " + result.isCancelled());
        System.out.println("Main: Concluída: " + result.isDone());

        // Encerra o executor
        executor.shutdown();
        System.out.println("Main: O executor terminou");
    }
}
