package ForkJoinPool;

import java.util.List;
import java.util.concurrent.RecursiveAction;

public class Task extends RecursiveAction {

    private static final long serialVersionUID = 1L;

    private List<Product> products;
    private int first;
    private int last;
    private double increment;

    /**
     * Construtor da classe.
     * @param products Lista de produtos.
     * @param first Índice inicial.
     * @param last Índice final.
     * @param increment Incremento de preço.
     */
    public Task(List<Product> products, int first, int last, double increment) {
        this.products = products;
        this.first = first;
        this.last = last;
        this.increment = increment;
    }

    @Override
    protected void compute() {
        // Se o intervalo de produtos for pequeno, atualiza os preços diretamente
        if (last - first < 10) {
            updatePrices();
        } else {
            // Caso contrário, divide a tarefa em duas subtarefas
            int middle = (last + first) / 2;
            System.out.println("Task: Pending tasks: " + getQueuedTaskCount());
            Task t1 = new Task(products, first, middle + 1, increment);
            Task t2 = new Task(products, middle + 1, last, increment);
            System.out.println("t1 : " + t1);
            System.out.println("t2 : " + t2);
            System.out.println();
            invokeAll(t1, t2);
        }
    }

    /**
     * Atualiza os preços dos produtos no intervalo especificado.
     */
    private void updatePrices() {
        System.out.println("first : " + this.first + "  last : " + last);
        System.out.println();
        for (int i = first; i < last; i++) {
            Product product = products.get(i);
            product.setPrice(product.getPrice() * (1 + increment));
        }
    }

    @Override
    public String toString() {
        return "Task [first=" + first + ", last=" + last + "]";
    }
}