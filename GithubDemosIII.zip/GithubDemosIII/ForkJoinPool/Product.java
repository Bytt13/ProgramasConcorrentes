package ForkJoinPool;

public class Product {
    private String name;
    private double price;

    /**
     * Obtém o nome do produto.
     * 
     * @return O nome do produto.
     */
    public String getName() {
        return name;
    }

    /**
     * Define o nome do produto.
     * 
     * @param name O nome do produto.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Obtém o preço do produto.
     * 
     * @return O preço do produto.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Define o preço do produto.
     * 
     * @param price O preço do produto.
     */
    public void setPrice(double price) {
        this.price = price;
    }
}