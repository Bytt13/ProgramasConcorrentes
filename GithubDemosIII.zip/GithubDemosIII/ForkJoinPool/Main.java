package ForkJoinPool;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        // Gera uma lista de produtos
        ProductListGenerator generator = new ProductListGenerator();
        List<Product> products = generator.generate(40);

        // Cria uma tarefa para atualizar os preços dos produtos
        Task task = new Task(products, 0, products.size(), 0.20);

        // Cria um ForkJoinPool
        ForkJoinPool pool = new ForkJoinPool();

        // Executa a tarefa no pool
        pool.execute(task);

        // Monitora o progresso da tarefa
        do {
            System.out.println("Main: Thread Count: " + pool.getActiveThreadCount());
            System.out.println("Main: Thread Steal: " + pool.getStealCount());
            System.out.println("Main: Paralelism: " + pool.getParallelism());

            try {
                TimeUnit.MILLISECONDS.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } while (!task.isDone());

        // Encerra o pool
        pool.shutdown();

        // Verifica se a tarefa foi concluída normalmente
        if (task.isCompletedNormally()) {
            System.out.println("Main: The process has completed normally.");
        }

        // Verifica os preços dos produtos
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            if (product.getPrice() != 12) {
                System.out.println("Product " + product.getName() + ": " + product.getPrice());
            }
        }

        System.out.println("Main: End of the program.");
    }
}
