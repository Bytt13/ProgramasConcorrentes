package RejectedTasks;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Classe que controla tarefas rejeitadas.
 * Implementa a interface RejectedExecutionHandler para lidar com tarefas rejeitadas.
 */
public class RejectedTaskController implements RejectedExecutionHandler {

    @Override
    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
        System.err.println("RejectedTaskController: The task " + r.toString() + " has been rejected");
        System.err.println("RejectedTaskController: " + executor.toString());
        System.err.println("RejectedTaskController: Terminating: " + executor.isTerminating());
        System.err.println("RejectedTaskController: Terminated: " + executor.isTerminated());
    }

}