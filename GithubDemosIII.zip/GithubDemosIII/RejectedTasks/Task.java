package RejectedTasks;

import java.util.concurrent.TimeUnit;

/**
 * Classe que representa uma tarefa.
 * Implementa a interface Runnable para que possa ser executada por uma thread.
 */
public class Task implements Runnable {
    private String name;

    /**
     * Construtor da classe.
     * @param name Nome da tarefa.
     */
    public Task(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println("Task " + name + ": Starting");
        try {
            Long duration = (long) (Math.random() * 10);
            System.out.println("Task " + name + ": ReportGenerator: Generating a report during " + duration + " seconds");
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Task " + name + ": Ending");
    }

    @Override
    public String toString() {
        return name;
    }
}