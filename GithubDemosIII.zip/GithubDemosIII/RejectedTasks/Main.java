package RejectedTasks;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Main {
    public static void main(String[] args) {
        // Cria um controlador de tarefas rejeitadas
        RejectedTaskController controller = new RejectedTaskController();
        // Cria um executor com um pool de threads cacheado
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
        // Define o controlador de tarefas rejeitadas
        executor.setRejectedExecutionHandler(controller);

        System.out.println("Main: Starting.");
        // Submete 3 tarefas ao executor
        for (int i = 0; i < 3; i++) {
            Task task = new Task("Task" + i);
            executor.submit(task);
        }

        System.out.println("Main: Shutting down the Executor.");
        // Encerra o executor
        executor.shutdown();
        System.out.println("Shutdown: " + executor.isShutdown());

        System.out.println("Main: Sending another Task.");
        // Tenta submeter outra tarefa após o encerramento do executor
        Task task = new Task("RejectedTask");
        executor.submit(task);

        System.out.println("Main: End.");
    }
}
