package MultiTaskGetFirst;

import java.util.concurrent.Callable;

/**
 * Classe que representa uma tarefa de validação de usuário.
 * Implementa a interface Callable para que possa ser executada por uma thread.
 */
public class TaskValidator implements Callable<String> {

    private UserValidator validator;
    private String user;
    private String password;

    /**
     * Construtor da classe.
     * @param validator Validador de usuário.
     * @param user Nome do usuário.
     * @param password Senha do usuário.
     */
    public TaskValidator(UserValidator validator, String user, String password) {
        this.validator = validator;
        this.user = user;
        this.password = password;
    }

    @Override
    public String call() throws Exception {
        // Valida o usuário e a senha
        if (!validator.validate(user, password)) {
            System.out.println(validator.getName() + ": The user has not been found");
            throw new Exception("Error validating user");
        }

        System.out.println(validator.getName() + ": The user has been found");
        return validator.getName();
    }

}