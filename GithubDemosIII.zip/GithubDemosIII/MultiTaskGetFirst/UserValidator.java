package MultiTaskGetFirst;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class UserValidator {
    private String name;

    /**
     * Construtor da classe.
     * @param name Nome do validador.
     */
    public UserValidator(String name) {
        this.name = name;
    }

    /**
     * Método que valida um usuário e sua senha.
     * 
     * @param name Nome do usuário.
     * @param password Senha do usuário.
     * @return true se o usuário for validado com sucesso, false caso contrário.
     */
    public boolean validate(String name, String password) {
        Random random = new Random();

        try {
            Long duration = (long) (Math.random() * 10);
            System.out.println("Validator " + this.name + ": Validating a user during " + duration + " seconds");
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            return false;
        }
        return random.nextBoolean();
    }

    /**
     * Obtém o nome do validador.
     * 
     * @return O nome do validador.
     */
    public String getName() {
        return name;
    }
}