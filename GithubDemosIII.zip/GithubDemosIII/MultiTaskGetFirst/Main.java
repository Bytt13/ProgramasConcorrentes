package MultiTaskGetFirst;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    /**
     * Método principal que valida um usuário utilizando múltiplos validadores e retorna o primeiro resultado.
     * 
     * @param args Argumentos da linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        String username = "test";
        String password = "test";

        // Cria instâncias dos validadores de usuário
        UserValidator ldapValidator = new UserValidator("LDAP");
        UserValidator dbValidator = new UserValidator("DataBase");

        // Cria tarefas de validação para cada validador
        TaskValidator ldapTask = new TaskValidator(ldapValidator, username, password);
        TaskValidator dbTask = new TaskValidator(dbValidator, username, password);

        // Adiciona as tarefas a uma lista
        List<TaskValidator> taskList = new ArrayList<>();
        taskList.add(ldapTask);
        taskList.add(dbTask);

        // Cria um ExecutorService com um pool de threads cacheado
        ExecutorService executor = Executors.newCachedThreadPool();
        String result;
        try {
            // Executa as tarefas e retorna o resultado da primeira que completar
            result = executor.invokeAny(taskList);
            System.out.println("Main: Result: " + result);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        // Encerra o executor
        executor.shutdown();
        System.out.println("Main: End of the Execution");
    }
}
