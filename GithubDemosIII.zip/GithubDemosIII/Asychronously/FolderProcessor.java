package Asychronously;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RecursiveTask;

public class FolderProcessor extends RecursiveTask<List<String>> {

    private static final long serialVersionUID = 1L;

    private String path;
    private String extension;

    /**
     * Construtor da classe.
     * @param path Caminho do diretório a ser processado.
     * @param extension Extensão dos arquivos a serem procurados.
     */
    public FolderProcessor(String path, String extension) {
        this.path = path;
        this.extension = extension;
    }

    @Override
    protected List<String> compute() {
        List<String> list = new ArrayList<>();
        List<FolderProcessor> tasks = new ArrayList<>();

        File file = new File(path);
        File[] content = file.listFiles();
        if (content != null) {
            for (int i = 0; i < content.length; i++) {
                if (content[i].isDirectory()) {
                    // Se o conteúdo for um diretório, cria uma nova tarefa para processá-lo
                    FolderProcessor task = new FolderProcessor(content[i].getAbsolutePath(), extension);
                    task.fork();
                    tasks.add(task);
                } else {
                    // Se o conteúdo for um arquivo, verifica se possui a extensão desejada
                    if (checkFile(content[i].getName())) {
                        list.add(content[i].getAbsolutePath());
                    }
                }
            }
            if (tasks.size() > 50) {
                System.out.println(file.getAbsolutePath() + ": " + tasks.size() + " tasks ran.");
            }

            // Adiciona os resultados das subtarefas à lista principal
            addResultsFromTasks(list, tasks);
        }

        return list;
    }

    /**
     * Adiciona os resultados das subtarefas à lista principal.
     * @param list Lista principal de resultados.
     * @param tasks Lista de subtarefas.
     */
    private void addResultsFromTasks(List<String> list, List<FolderProcessor> tasks) {
        for (FolderProcessor item : tasks) {
            list.addAll(item.join());
        }
    }

    /**
     * Verifica se o arquivo possui a extensão desejada.
     * @param name Nome do arquivo.
     * @return true se o arquivo possui a extensão desejada, false caso contrário.
     */
    private boolean checkFile(String name) {
        return name.endsWith(extension);
    }
}
