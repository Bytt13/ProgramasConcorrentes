package Asychronously;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        // Cria um ForkJoinPool
        ForkJoinPool pool = new ForkJoinPool();

        // Cria três tarefas FolderProcessor para diferentes diretórios
        FolderProcessor system = new FolderProcessor("C:\\Windows", "log");
        FolderProcessor apps = new FolderProcessor("C:\\Program Files", "log");
        FolderProcessor documents = new FolderProcessor("C:\\Documents And Settings", "log");

        // Executa as tarefas no pool
        pool.execute(system);
        pool.execute(apps);
        pool.execute(documents);

        // Monitora o progresso das tarefas
        do {
            System.out.println("******************************************");
            System.out.println("Main: Parallelism: " + pool.getParallelism());
            System.out.println("Main: Active Threads: " + pool.getActiveThreadCount());
            System.out.println("Main: Task Count: " + pool.getQueuedTaskCount());
            System.out.println("Main: Steal Count: " + pool.getStealCount());
            System.out.println("******************************************");
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } while ((!system.isDone()) || (!apps.isDone()) || (!documents.isDone()));

        // Encerra o pool
        pool.shutdown();

        List<String> results;

        // Obtém e imprime os resultados das tarefas
        results = system.join();
        System.out.println("System: " + results.size() + " files found.");

        results = apps.join();
        System.out.println("Apps: " + results.size() + " files found.");

        results = documents.join();
        System.out.println("Documents: " + results.size() + " files found.");
    }
}
