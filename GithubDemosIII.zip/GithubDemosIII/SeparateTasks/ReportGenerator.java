package SeparateTasks;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

/**
 * Classe que representa um gerador de relatórios.
 * Implementa a interface Callable para que possa ser executada por uma thread.
 */
public class ReportGenerator implements Callable<String> {
    private String sender;
    private String title;

    /**
     * Construtor da classe.
     * @param sender Remetente do relatório.
     * @param title Título do relatório.
     */
    public ReportGenerator(String sender, String title) {
        this.sender = sender;
        this.title = title;
    }

    @Override
    public String call() throws Exception {
        try {
            Long duration = (long) (Math.random() * 10);
            System.out.println(this.sender + "_" + this.title + ": ReportGenerator: Generating a report during " + duration + " seconds");
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String ret = sender + ": " + title;
        return ret;
    }
}
