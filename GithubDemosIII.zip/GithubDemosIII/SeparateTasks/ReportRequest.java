package SeparateTasks;

import java.util.concurrent.CompletionService;

/**
 * Classe que representa uma solicitação de relatório.
 * Implementa a interface Runnable para que possa ser executada por uma thread.
 */
public class ReportRequest implements Runnable {
    private String name;
    private CompletionService<String> service;

    /**
     * Construtor da classe.
     * @param name Nome da solicitação.
     * @param service CompletionService utilizado para submeter a tarefa.
     */
    public ReportRequest(String name, CompletionService<String> service) {
        this.name = name;
        this.service = service;
    }

    @Override
    public void run() {
        // Cria um gerador de relatórios
        ReportGenerator reportGenerator = new ReportGenerator(name, "Report");
        // Usa CompletionService para submeter a tarefa
        service.submit(reportGenerator);
    }
}
