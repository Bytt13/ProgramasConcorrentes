package SeparateTasks;

import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Classe que processa relatórios recebidos de um CompletionService.
 * Implementa a interface Runnable para que possa ser executada por uma thread.
 */
public class ReportProcessor implements Runnable {
    private CompletionService<String> service;
    private boolean end;

    /**
     * Construtor da classe.
     * @param service CompletionService utilizado para receber os relatórios.
     */
    public ReportProcessor(CompletionService<String> service) {
        this.service = service;
        end = false;
    }

    @Override
    public void run() {
        while (!end) {
            try {
                // Aguarda por um relatório por até 20 segundos
                Future<String> result = service.poll(20, TimeUnit.SECONDS);
                if (result != null) {
                    String report = result.get();
                    System.out.println("ReportReceiver: Report Received: " + report);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
        
        System.out.println("ReportSender: End");
    }

    /**
     * Define o estado de término do processamento.
     * @param end true para terminar o processamento, false caso contrário.
     */
    public void setEnd(boolean end) {
        this.end = end;
    }
}
