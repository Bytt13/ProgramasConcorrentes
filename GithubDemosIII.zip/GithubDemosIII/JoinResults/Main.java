package JoinResults;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        // Cria um mock de documento
        DocumentMock mock = new DocumentMock();
        // Gera um documento com 10 linhas e 100 palavras por linha
        String[][] document = mock.generateDocument(10, 100, "the");

        // Cria uma tarefa para contar as ocorrências da palavra "the"
        DocumentTask task = new DocumentTask(document, 0, 10, "the");
        // Cria um ForkJoinPool
        ForkJoinPool pool = new ForkJoinPool();

        // Executa a tarefa no pool
        pool.execute(task);

        // Monitora o progresso da tarefa
        do {
            System.out.println("******************************************");
            System.out.println("Main: Parallelism: " + pool.getParallelism());
            System.out.println("Main: Active Threads: " + pool.getActiveThreadCount());
            System.out.println("Main: Task Count: " + pool.getQueuedTaskCount());
            System.out.println("Main: Steal Count: " + pool.getStealCount());
            System.out.println("******************************************");

            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        } while (!task.isDone());

        // Encerra o pool
        pool.shutdown();
        try {
            pool.awaitTermination(1, TimeUnit.DAYS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Imprime o resultado final
        try {
            System.out.println("Main: The word appears " + task.get() + " in the document");
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
