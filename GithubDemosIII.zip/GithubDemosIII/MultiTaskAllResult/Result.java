package MultiTaskAllResult;

/**
 * Classe que representa o resultado de uma tarefa.
 */
public class Result {
    private String name;
    private int value;

    /**
     * Obtém o nome da tarefa.
     * 
     * @return O nome da tarefa.
     */
    public String getName() {
        return name;
    }

    /**
     * Define o nome da tarefa.
     * 
     * @param name O nome da tarefa.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Obtém o valor do resultado da tarefa.
     * 
     * @return O valor do resultado.
     */
    public int getValue() {
        return value;
    }

    /**
     * Define o valor do resultado da tarefa.
     * 
     * @param value O valor do resultado.
     */
    public void setValue(int value) {
        this.value = value;
    }
}
