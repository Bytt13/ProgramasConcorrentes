package MultiTaskAllResult;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main {
    /**
     * Método principal que executa múltiplas tarefas e imprime os resultados.
     * 
     * @param args Argumentos da linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        // Cria um ExecutorService com um pool de threads cacheado
        ExecutorService executor = Executors.newCachedThreadPool();

        // Cria uma lista de tarefas
        List<Task> taskList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            Task task = new Task("Task-" + i);
            taskList.add(task);
        }

        List<Future<Result>> resultList = null;

        // Imprime a data e hora de início
        System.out.println(new Date());
        try {
            // Executa todas as tarefas e obtém uma lista de Future<Result>
            resultList = executor.invokeAll(taskList);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Encerra o executor
        executor.shutdown();
        System.out.println(new Date());

        // Imprime os resultados das tarefas
        System.out.println("Core: Printing the results");
        for (int i = 0; i < resultList.size(); i++) {
            Future<Result> future = resultList.get(i);

            try {
                Result result = future.get();
                System.out.println(result.getName() + ": " + result.getValue());
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
    }
}
