package PeriodicTask;

import java.util.Date;

/**
 * Classe que representa uma tarefa periódica.
 * Implementa a interface Runnable para que possa ser executada por uma thread.
 */
public class Task implements Runnable {

    private String name;

    /**
     * Construtor da classe.
     * @param name Nome da tarefa.
     */
    public Task(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println(name + ": Executed at: " + new Date());
    }

}
