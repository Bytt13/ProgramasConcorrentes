package ControlTask;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

/**
 * Classe que representa uma tarefa executável.
 * Implementa a interface Callable para que possa ser executada por uma thread.
 */
public class ExecutableTask implements Callable<String> {

    private String name;

    /**
     * Construtor da classe.
     * @param name Nome da tarefa.
     */
    public ExecutableTask(String name) {
        this.name = name;
    }

    @Override
    public String call() throws Exception {
        try {
            Long duration = (long) (Math.random() * 10);
            System.out.println(this.name + ": Waiting " + duration + " seconds for results.");
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            // Tratamento de interrupção
        }
        return "Hello, world. I'm " + name;
    }

    /**
     * Obtém o nome da tarefa.
     * 
     * @return O nome da tarefa.
     */
    public String getName() {
        return this.name;
    }
}