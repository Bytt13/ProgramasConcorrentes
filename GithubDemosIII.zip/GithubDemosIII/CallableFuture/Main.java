package CallableFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class Main {
    /**
     * Método principal que executa o cálculo do fatorial de números aleatórios
     * utilizando um pool de threads.
     * 
     * @param args Argumentos da linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        // Cria um executor com um pool de threads fixo de tamanho 2
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);
        // Lista para armazenar os resultados futuros das tarefas
        List<Future<Integer>> resultList = new ArrayList<>();

        // Cria um gerador de números aleatórios
        Random random = new Random();
        // Submete 10 tarefas de cálculo de fatorial ao executor
        for (int i = 0; i < 10; i++) {
            Integer number = new Integer(random.nextInt(10));
            FactorialCalculator calculator = new FactorialCalculator(number);
            Future<Integer> result = executor.submit(calculator);
            resultList.add(result);
        }

        // Verifica periodicamente o número de tarefas concluídas
        do {
            System.out.println("Main: Number of Completed Tasks: " + executor.getCompletedTaskCount());
            for (int i = 0; i < resultList.size(); i++) {
                Future<Integer> result = resultList.get(i);
                System.out.println("Main: Task " + i + ": " + result.isDone());
            }
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } while (executor.getCompletedTaskCount() < resultList.size());

        // Exibe os resultados das tarefas
        System.out.println("Main: Results");
        for (int i = 0; i < resultList.size(); i++) {
            Future<Integer> result = resultList.get(i);
            Integer number = null;
            try {
                number = result.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            System.out.println("Core: Task " + i + ": " + number);
        }

        // Encerra o executor
        executor.shutdown();
    }
}