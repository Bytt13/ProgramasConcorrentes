package CallableFuture;

import java.util.concurrent.Callable;

/**
 * Classe que calcula o fatorial de um número.
 * Implementa a interface Callable para que possa ser executada por uma thread.
 */
public class FactorialCalculator implements Callable<Integer> {
    private Integer number;

    /**
     * Construtor da classe.
     * @param number Número do qual será calculado o fatorial.
     */
    public FactorialCalculator(Integer number) {
        this.number = number;
    }

    /**
     * Método que realiza o cálculo do fatorial.
     * @return O resultado do fatorial do número.
     * @throws Exception Se ocorrer alguma interrupção durante a execução.
     */
    @Override
    public Integer call() throws Exception {
        int num, result;

        num = number.intValue();
        result = 1;

        // Verifica se o número é 0 ou 1, pois o fatorial de ambos é 1
        if (num == 0 || num == 1) {
            result = 1;
        } else {
            // Calcula o fatorial do número
            for (int i = 2; i <= number; i++) {
                result *= i;
                Thread.sleep(20); // Simula um atraso na execução
            }
        }

        // Imprime o resultado do cálculo
        System.out.println(Thread.currentThread().getName() + ": " + result);
        
        return result;
    }

}