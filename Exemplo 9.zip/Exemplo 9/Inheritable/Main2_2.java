package GithubDemos.Inheritable;

public class Main2_2 {
    
    private static InheritableThreadLocal<StringBuffer> threadLocal = new InheritableThreadLocal<StringBuffer>() {
        @Override
        protected StringBuffer initialValue() {
            return new StringBuffer("aaa");
        }
    };

    public static void main(String[] args){
        // Imprime o valor inicial do InheritableThreadLocal na thread principal
        System.out.println("begin = " + threadLocal.get());

        // Cria e inicia uma nova thread
        Thread a = new Thread(new Runnable(){
            @Override
            public void run() {
                // Imprime o valor do InheritableThreadLocal na thread "a" no início
                System.out.println("thread begin = " + threadLocal.get());
                // Modifica o valor do InheritableThreadLocal na thread "a"
                threadLocal.set(threadLocal.get().append("bbb"));
                // Imprime o valor modificado do InheritableThreadLocal na thread "a"
                System.out.println("thread ends = " + threadLocal.get());
            }
        });

        a.start();

        try {
            // Pausa a execução da thread principal por 2 segundos
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Imprime o valor do InheritableThreadLocal na thread principal após a pausa
        System.out.println("end = " + threadLocal.get());   
    }
}
