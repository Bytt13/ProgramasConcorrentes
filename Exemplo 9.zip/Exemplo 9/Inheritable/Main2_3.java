package GithubDemos.Inheritable;

public class Main2_3 {
    private final static InheritableThreadLocal<String> threadLocal = new InheritableThreadLocal<String>(){
        @Override
        protected String childValue(String parentValue){
            return parentValue + " from child";
        }
    };

    public static void main(String[] args){
        // Define o valor do InheritableThreadLocal na thread principal
        threadLocal.set("Hello");
        // Imprime o valor do InheritableThreadLocal na thread principal
        System.out.println("Main: " + threadLocal.get());

        // Cria e inicia uma nova thread
        new Thread(() -> {
            // Imprime o valor do InheritableThreadLocal na thread "Child"
            System.out.println("Child: " + threadLocal.get());
            // Modifica o valor do InheritableThreadLocal na thread "Child"
            threadLocal.set("World");
            // Imprime o valor modificado do InheritableThreadLocal na thread "Child"
            System.out.println("Child: " + threadLocal.get());
        }).start();

        try{
            // Pausa a execução da thread principal por 1 segundo
            Thread.sleep(1000);
        } catch (InterruptedException e){
            e.printStackTrace();
        }

        // Imprime o valor do InheritableThreadLocal na thread principal após a pausa
        System.out.println("Main: " + threadLocal.get());
    }
}
