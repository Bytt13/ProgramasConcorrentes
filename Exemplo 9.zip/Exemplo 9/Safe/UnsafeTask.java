package GithubDemos.Safe;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * A classe UnsafeTask implementa a interface Runnable e demonstra uma tarefa que não é segura para threads.
 */
public class UnsafeTask implements Runnable{
    
    // Data de início da thread
    private Date startDate;

    @Override
    public void run(){
        // Define a data de início da thread
        startDate = new Date();
        System.out.println("Thread: " + Thread.currentThread().getId() + " Start Time: " + startDate);

        try{
            // Pausa a execução da thread por um tempo aleatório entre 0 e 10 segundos
            TimeUnit.SECONDS.sleep((int)Math.rint(Math.random()*10));
        } catch (InterruptedException e){
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }

        // Imprime a data de término da thread
        System.out.println("Thread: " + Thread.currentThread().getId() + " End Time: " + startDate);
    }
}
