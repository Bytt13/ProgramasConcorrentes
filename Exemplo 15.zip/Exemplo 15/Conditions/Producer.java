package GithubDemos.Conditions;

/**
 * A classe Producer implementa a interface Runnable e adiciona eventos a um armazenamento de eventos.
 */
public class Producer implements Runnable{
    private EventStorage storage;
    
    /**
     * Construtor da classe Producer.
     * 
     * @param storage A instância de EventStorage onde os eventos serão adicionados.
     */
    public Producer(EventStorage storage){
        this.storage = storage;
    }
    
    @Override
    public void run(){
        for(int i = 0; i < 100; i++){
            // Adiciona um evento ao armazenamento de eventos
            storage.set();
        }
    }
}
