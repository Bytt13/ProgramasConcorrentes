package GithubDemos.Conditions;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * A classe EventStorage armazena eventos em uma lista e permite adicionar e remover eventos de forma sincronizada.
 */
public class EventStorage {
    
    private int maxSize;
    private List<Date> storage;

    /**
     * Construtor da classe EventStorage.
     * Inicializa a lista de armazenamento e define o tamanho máximo.
     */
    public EventStorage(){
        maxSize = 10;
        storage = new LinkedList<>();
    }

    /**
     * Adiciona um evento à lista de armazenamento de forma sincronizada.
     * Se a lista estiver cheia, a thread espera até que haja espaço disponível.
     */
    public synchronized void set(){
        while(storage.size() == maxSize){
            try{
                wait();
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }

        storage.add(new Date());
        System.out.println("Set: " + storage.size());

        notify();
    }

    /**
     * Remove um evento da lista de armazenamento de forma sincronizada.
     * Se a lista estiver vazia, a thread espera até que haja eventos disponíveis.
     */
    public synchronized void get(){
        while(storage.size() == 0){
            try{
                wait();
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }

        System.out.println("Get: " + storage.size() + ": " + ((LinkedList<?>)storage).poll());

        notify();
    }
}
