package GithubDemos.UncheckedException;

/**
 * A classe Task implementa a interface Runnable e simula uma tarefa que gera uma exceção não capturada.
 */
public class Task implements Runnable {
    
    /**
     * O método run é executado quando a thread é iniciada.
     * Ele tenta converter uma string inválida para um inteiro, o que gera uma exceção NumberFormatException.
     */
    @Override
    public void run() {
        // Tenta converter uma string inválida para um inteiro, gerando uma exceção NumberFormatException
        Integer.parseInt("TTT");
        // Esta linha não será executada devido à exceção
        System.out.println("=====run end=====");
    }    
}
