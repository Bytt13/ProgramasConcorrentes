package GithubDemos.Arrange;

/**
 * A classe TicketOffice implementa a interface Runnable e simula a venda e devolução de ingressos em um cinema.
 */
public class TicketOffice implements Runnable{
    private Cinema cinema;

    /**
     * Construtor da classe TicketOffice.
     * 
     * @param cinema A instância de Cinema onde os ingressos serão vendidos e devolvidos.
     */
    public TicketOffice(Cinema cinema){
        this.cinema = cinema;
    }

    @Override
    public void run(){
        cinema.sellTickets1(3);
        cinema.sellTickets1(2);
        cinema.sellTickets2(2);
        cinema.returnTickets1(3);
        cinema.sellTickets1(5);
        cinema.sellTickets2(2);
        cinema.sellTickets2(2);
        cinema.sellTickets2(2);
    }
}
