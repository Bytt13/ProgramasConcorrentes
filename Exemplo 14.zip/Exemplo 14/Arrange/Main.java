package GithubDemos.Arrange;

/**
 * A classe Main contém o método principal que inicia a execução do programa.
 */
public class Main {
    public static void main(String[] args) {
        // Cria uma instância de Cinema
        Cinema cinema = new Cinema();

        // Cria uma instância de TicketOffice e uma thread para executá-lo
        TicketOffice ticketOffice1 = new TicketOffice(cinema);
        Thread thread1 = new Thread(ticketOffice1, "Ticket Office 1");
        
        // Cria uma instância de TicketOffice2 e uma thread para executá-lo
        TicketOffice2 ticketOffice2 = new TicketOffice2(cinema);
        Thread thread2 = new Thread(ticketOffice2, "Ticket Office 2");

        // Inicia as threads dos escritórios de ingressos
        thread1.start();
        thread2.start();

        try {
            // Aguarda a conclusão das threads
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            // Imprime a stack trace se a thread for interrompida
            e.printStackTrace();
        }

        // Imprime o número de vagas disponíveis em cada sala de cinema
        System.out.println("Room 1 Vacancies: " + cinema.getVacanciesCinema1());
        System.out.println("Room 2 Vacancies: " + cinema.getVacanciesCinema2());
    }
}