package ControlPhaserChange;

import java.util.Date;
import java.util.concurrent.Phaser;
import java.util.concurrent.TimeUnit;

public class Student implements Runnable {
    private Phaser phaser;

    // Construtor que recebe uma instância de Phaser
    public Student(Phaser phaser) {
        this.phaser = phaser;
    }

    @Override
    public void run() {
        // Indica que o estudante chegou para fazer o exame
        System.out.println(Thread.currentThread().getName() + ": Has arrived to do the exam. " + new Date());
        phaser.arriveAndAwaitAdvance();
        
        // Indica que o estudante vai fazer o primeiro exercício
        System.out.println(Thread.currentThread().getName() + ": Is going to do the first exercise. " + new Date());
        doExercise1();
        // Indica que o estudante terminou o primeiro exercício
        System.out.println(Thread.currentThread().getName() + ": Has done the first exercise. " + new Date());
        phaser.arriveAndAwaitAdvance();
        
        // Indica que o estudante vai fazer o segundo exercício
        System.out.println(Thread.currentThread().getName() + ": Is going to do the second exercise. " + new Date());
        doExercise2();
        // Indica que o estudante terminou o segundo exercício
        System.out.println(Thread.currentThread().getName() + ": Has done the second exercise. " + new Date());
        phaser.arriveAndAwaitAdvance();
        
        // Indica que o estudante vai fazer o terceiro exercício
        System.out.println(Thread.currentThread().getName() + ": Is going to do the third exercise. " + new Date());
        doExercise3();
        // Indica que o estudante terminou o exame
        System.out.println(Thread.currentThread().getName() + ": Has finished the exam. " + new Date());
        phaser.arriveAndAwaitAdvance();
    }

    // Método para simular a realização do primeiro exercício
    private void doExercise1() {
        try {
            Long duration = (long) (Math.random() * 10);
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Método para simular a realização do segundo exercício
    private void doExercise2() {
        try {
            Long duration = (long) (Math.random() * 10);
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Método para simular a realização do terceiro exercício
    private void doExercise3() {
        try {
            Long duration = (long) (Math.random() * 10);
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}