package ControlPhaserChange;

public class Main {
    public static void main(String[] args) {
        // Cria uma instância de MyPhaser
        MyPhaser phaser = new MyPhaser();

        // Cria um array de estudantes
        Student[] students = new Student[5];
        for (int i = 0; i < students.length; i++) {
            students[i] = new Student(phaser);
            phaser.register();
        }

        // Cria e inicia as threads para cada estudante
        Thread threads[] = new Thread[students.length];
        for (int i = 0; i < students.length; i++) {
            threads[i] = new Thread(students[i], "Student " + i);
            threads[i].start();
        }

        // Aguarda a conclusão de todas as threads
        for (int i = 0; i < threads.length; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Verifica se o Phaser foi terminado
        System.out.println("Main: The phaser has finished: " + phaser.isTerminated() + ".");
    }
}