package CyclicBarrier;

public class Results {

    private int data[];

    /**
     * Construtor que inicializa o array de resultados com o tamanho especificado
     * 
     * @param size Tamanho do array de resultados
     */
    public Results(int size) {
        data = new int[size];
    }

    /**
     * Método para definir o valor em uma posição específica do array de resultados
     * 
     * @param position Posição no array
     * @param value    Valor a ser definido
     */
    public void setData(int position, int value) {
        data[position] = value;
    }

    /**
     * Método para obter o array de resultados
     * 
     * @return O array de resultados
     */
    public int[] getData() {
        return data;
    }
}
