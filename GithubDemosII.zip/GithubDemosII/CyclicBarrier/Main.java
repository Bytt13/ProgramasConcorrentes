package CyclicBarrier;

import java.util.concurrent.CyclicBarrier;

public class Main {

    public static void main(String[] args) {

        /*
         * Define as constantes para a matriz e a busca
         */
        final int ROWS = 10000;					// Número de linhas da matriz
        final int NUMBERS = 1000;				// Número de números por linha
        final int SEARCH = 5;					// Número a ser buscado na matriz
        final int LINES_PARTICIPANT = 2000;		// Número de linhas que cada participante irá processar
        
        // Cria uma instância de MatrixMock com os parâmetros definidos
        MatrixMock mock = new MatrixMock(ROWS, NUMBERS, SEARCH);

        // Cria uma instância de Results para armazenar os resultados
        Results results = new Results(ROWS);

        // Cria uma instância de Grouper que será executada quando todos os participantes terminarem
        Grouper grouper = new Grouper(results);

        // Define o número de participantes
        final int PARTICIPANTS = 5;
        
        // Cria uma instância de CyclicBarrier com o número de participantes e o grouper
        CyclicBarrier barrier = new CyclicBarrier(PARTICIPANTS, grouper);

        // Cria e inicializa os participantes (Searchers)
        Searcher searchers[] = new Searcher[PARTICIPANTS];
        for (int i = 0; i < PARTICIPANTS; i++) {
            searchers[i] = new Searcher(i * LINES_PARTICIPANT, (i * LINES_PARTICIPANT) + LINES_PARTICIPANT, mock,
                    results, 5, barrier);
            Thread thread = new Thread(searchers[i]);
            thread.start();
        }
        
        // Imprime uma mensagem indicando que a thread principal terminou
        System.out.println("Main: The main thread has finished.");
    }

}
