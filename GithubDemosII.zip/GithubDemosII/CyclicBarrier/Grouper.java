package CyclicBarrier;

/**
 * Classe Grouper que processa os resultados finais após todos os participantes terminarem
 */
public class Grouper implements Runnable {

    /**
     * Instância de Results para armazenar os resultados
     */
    private Results results;

    /**
     * Construtor que recebe uma instância de Results
     * 
     * @param results Instância de Results
     */
    public Grouper(Results results) {
        this.results = results;
    }

    /**
     * Método run que processa os resultados finais
     */
    @Override
    public void run() {
        int finalResult = 0;
        System.out.println("Grouper: Processing results...");
        int data[] = results.getData();
        for (int number : data) {
            finalResult += number;
        }
        System.out.println("Grouper: Total result: " + finalResult + ".");
    }

}