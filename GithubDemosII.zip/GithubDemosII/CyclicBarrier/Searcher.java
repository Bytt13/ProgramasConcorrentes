package CyclicBarrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Searcher implements Runnable {

    private int firstRow;
    private int lastRow;
    private MatrixMock mock;
    private Results results;
    private int number;

    /**
     * CyclicBarrier para sincronizar os participantes
     */
    private final CyclicBarrier barrier;

    /**
     * Construtor que inicializa os atributos da classe
     * 
     * @param firstRow Primeira linha a ser processada
     * @param lastRow  Última linha a ser processada
     * @param mock     Instância de MatrixMock
     * @param results  Instância de Results
     * @param number   Número a ser buscado
     * @param barrier  Instância de CyclicBarrier
     */
    public Searcher(int firstRow, int lastRow, MatrixMock mock, Results results, int number, CyclicBarrier barrier) {
        this.firstRow = firstRow;
        this.lastRow = lastRow;
        this.mock = mock;
        this.results = results;
        this.number = number;
        this.barrier = barrier;
    }

    @Override
    public void run() {
        int counter;	
        System.out.println(Thread.currentThread().getName() + ": Processing lines from " + firstRow + " to " + lastRow + ".");
        
        // Processa cada linha atribuída ao Searcher
        for (int i = firstRow; i < lastRow; i++) {
            int row[] = mock.getRow(i);	
            counter = 0;
            // Conta as ocorrências do número na linha
            for (int j = 0; j < row.length; j++) {
                if (row[j] == number) {
                    counter++;
                }
            }
            
            // Armazena o resultado no objeto Results
            results.setData(i, counter);
        }
        
        System.out.println(Thread.currentThread().getName() + ": Lines processed.");
        
        try {
            // Aguarda até que todos os participantes tenham terminado
            barrier.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (BrokenBarrierException e) {
            e.printStackTrace();
        }
    }

}
