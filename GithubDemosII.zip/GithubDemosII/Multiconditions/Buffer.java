package Multiconditions;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Classe Buffer que gerencia uma fila de linhas com controle de concorrência
 */
public class Buffer {
    // Lista encadeada para armazenar as linhas
    private LinkedList<String> buffer;

    // Tamanho máximo do buffer
    private int maxSize;

    // Lock para gerenciar o acesso ao buffer
    private ReentrantLock lock;

    // Condições para gerenciar a espera de linhas e espaço no buffer
    private Condition lines;
    private Condition space;

    // Flag para indicar se há linhas pendentes
    private boolean pendingLines;

    public Buffer(int maxSize) {
        // Inicializa o tamanho máximo do buffer
        this.maxSize = maxSize;
        buffer = new LinkedList<>();
        lock = new ReentrantLock();
        lines = lock.newCondition();
        space = lock.newCondition();
        pendingLines = true;
    }

    /**
     * Insere uma linha no buffer
     */
    public void insert(String line) {
        // Adquire o lock antes de inserir a linha
        lock.lock();

        try {
            // Aguarda até que haja espaço no buffer
            while (buffer.size() == maxSize) {
                space.await();	
            }

            // Insere a linha no buffer
            buffer.offer(line);
            System.out.println(Thread.currentThread().getName() + ": Inserted Line: " + buffer.size());
            // Sinaliza que há novas linhas disponíveis
            lines.signalAll();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Libera o lock após a inserção
            lock.unlock();
        }
    }

    /**
     * Obtém uma linha do buffer
     */
    public String get() {
        String line = null;
        // Adquire o lock antes de obter a linha
        lock.lock();
        try {
            // Aguarda até que haja linhas disponíveis ou não haja mais linhas pendentes
            while ((buffer.size() == 0) && hasPendingLines()) {
                lines.await();
            }

            // Se houver linhas pendentes, obtém a linha do buffer
            if (hasPendingLines()) {
                line = buffer.poll();
                System.out.println(Thread.currentThread().getName() + ": Line Readed: " + buffer.size());
                // Sinaliza que há espaço disponível no buffer
                space.signalAll();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Libera o lock após obter a linha
            lock.unlock();
        }

        return line;
    }

    // Define se há linhas pendentes
    public void setPendingLines(boolean pendingLines) {
        this.pendingLines = pendingLines;
    }

    // Verifica se há linhas pendentes
    public boolean hasPendingLines() {
        return pendingLines || buffer.size() > 0;
    }
}