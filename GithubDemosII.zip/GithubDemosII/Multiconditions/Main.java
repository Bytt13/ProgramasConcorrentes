package Multiconditions;

public class Main {
    public static void main(String[] args) {
        // Cria uma instância de FileMock com 101 linhas de comprimento 10
        FileMock mock = new FileMock(101, 10);

        // Cria uma instância de Buffer com tamanho máximo de 20
        Buffer buffer = new Buffer(20);

        // Cria e inicializa o produtor
        Producer producer = new Producer(mock, buffer);
        Thread threadProducer = new Thread(producer, "Producer");

        // Cria e inicializa os consumidores
        Consumer consumers[] = new Consumer[3];
        Thread threadConsumers[] = new Thread[3];

        for (int i = 0; i < 3; i++) {
            consumers[i] = new Consumer(buffer);
            threadConsumers[i] = new Thread(consumers[i], "Consumer " + i);
        }

        // Inicia a thread do produtor
        threadProducer.start();
        // Inicia as threads dos consumidores
        for (int i = 0; i < 3; i++) {
            threadConsumers[i].start();
        }
    }
}