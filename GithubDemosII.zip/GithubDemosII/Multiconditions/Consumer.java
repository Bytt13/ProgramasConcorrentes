package Multiconditions;
import java.util.Random;

public class Consumer implements Runnable {
    private Buffer buffer;

    // Construtor que recebe uma instância de Buffer
    public Consumer(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        // Enquanto houver linhas pendentes no buffer
        while (buffer.hasPendingLines()) {
            // Obtém uma linha do buffer
            String line = buffer.get();
            // Processa a linha
            processLine(line);
        }
    }

    // Método para processar uma linha
    private void processLine(String line) {
        try {
            // Simula o processamento da linha com um atraso aleatório
            Random random = new Random();
            Thread.sleep(random.nextInt(100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
