package Multiconditions;

/**
 * Classe que simula um arquivo com várias linhas de conteúdo
 */
public class FileMock {

    // Array de strings para armazenar o conteúdo do arquivo
    private String[] content;

    // Índice para controlar a leitura do conteúdo
    private int index;

    /**
     * Construtor que inicializa o conteúdo do arquivo com linhas aleatórias
     * 
     * @param size   Número de linhas do arquivo
     * @param length Comprimento de cada linha
     */
    public FileMock(int size, int length) {
        content = new String[size];
        for (int i = 0; i < size; i++) {
            StringBuilder buffer = new StringBuilder(length);
            for (int j = 0; j < length; j++) {
                int indice = (int) (Math.random() * 255);
                buffer.append((char) indice);
            }

            content[i] = buffer.toString();
        }

        index = 0;
    }

    /**
     * Verifica se há mais linhas para serem lidas
     * 
     * @return true se houver mais linhas, false caso contrário
     */
    public boolean hasMoreLines() {
        return index < content.length;
    }

    /**
     * Obtém a próxima linha do arquivo
     * 
     * @return A próxima linha do arquivo ou null se não houver mais linhas
     */
    public String getLine() {
        if (this.hasMoreLines()) {
            System.out.println("Mock: " + (content.length - index));
            return content[index++];
        }

        return null;
    }
}