package Multiconditions;

public class Producer implements Runnable {
    private FileMock mock;
    private Buffer buffer;

    // Construtor que recebe uma instância de FileMock e Buffer
    public Producer(FileMock mock, Buffer buffer) {
        this.mock = mock;
        this.buffer = buffer;
    }

    @Override
    public void run() {
        // Define que há linhas pendentes no buffer
        buffer.setPendingLines(true);
        
        // Enquanto houver mais linhas no mock
        while (mock.hasMoreLines()) {
            // Obtém uma linha do mock
            String line = mock.getLine();
            // Insere a linha no buffer
            buffer.insert(line);
        }
        
        // Define que não há mais linhas pendentes no buffer
        buffer.setPendingLines(false);
    }
}