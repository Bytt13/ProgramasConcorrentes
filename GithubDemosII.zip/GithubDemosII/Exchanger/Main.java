package Exchanger;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Exchanger;

public class Main {
    public static void main(String[] args) {
        // Cria dois buffers para troca de dados
        List<String> buffer1 = new ArrayList<>();
        List<String> buffer2 = new ArrayList<>();

        // Cria uma instância de Exchanger para trocar os buffers entre produtor e consumidor
        Exchanger<List<String>> exchanger = new Exchanger<>();

        // Cria instâncias de Producer e Consumer
        Producer producer = new Producer(buffer1, exchanger);
        Consumer consumer = new Consumer(buffer2, exchanger);

        // Cria e inicia as threads para produtor e consumidor
        Thread threadProducer = new Thread(producer);
        Thread threadConsumer = new Thread(consumer);

        threadProducer.start();
        threadConsumer.start();
    }
}