package FixSizeExecutor;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Server {
    private ThreadPoolExecutor executor;

    // Construtor que inicializa o ThreadPoolExecutor com um pool de threads fixo
    public Server() {
        executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(5);
    }

    // Método para executar uma nova tarefa
    public void executeTask(Task task) {
        System.out.println("Server: A new task has arrived");
        executor.execute(task);
        System.out.println("Server: Pool Size: " + executor.getPoolSize());
        System.out.println("Server: Active Count: " + executor.getActiveCount());
        System.out.println("Server: Task Count: " + executor.getTaskCount());
        System.out.println("Server: Completed Tasks: " + executor.getCompletedTaskCount());
    }
    
    // Método para finalizar o servidor
    public void endServer() {
        executor.shutdown();
    }
}