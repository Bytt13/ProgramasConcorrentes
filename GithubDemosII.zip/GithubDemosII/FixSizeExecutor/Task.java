package FixSizeExecutor;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Task implements Runnable {
    private Date initDate;
    private String name;

    // Construtor que inicializa o nome da tarefa e a data de criação
    public Task(String name) {
        initDate = new Date();
        this.name = name;
    }

    @Override
    public void run() {
        // Imprime a data de criação da tarefa
        System.out.println(Thread.currentThread().getName() + ": Task " + name + ": Created on: " + initDate);
        // Imprime a data de início da tarefa
        System.out.println(Thread.currentThread().getName() + ": Task " + name + ": Started on: " + new Date());

        try {
            // Simula a execução da tarefa por um tempo aleatório
            Long duration = (long) (Math.random() * 10);
            System.out.println(Thread.currentThread().getName() + ": Task " + name + ": Doing a task during " + duration + " seconds");
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Imprime a data de término da tarefa
        System.out.println(Thread.currentThread().getName() + ": Task " + name + ": Finished on: " + new Date());
    }
}