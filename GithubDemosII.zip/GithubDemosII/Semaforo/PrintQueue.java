package Semaforo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Classe que representa uma fila de impressão controlada por um semáforo
 */
public class PrintQueue {
    // Semáforo para gerenciar o acesso à fila de impressão
    private final Semaphore semaphore;
    // Formato de data para exibir o tempo
    private final SimpleDateFormat sdf = new SimpleDateFormat("mm:ss.SSS");

    public PrintQueue() {
        // Inicializa o semáforo com 2 permissões
        semaphore = new Semaphore(2);
    }

    /**
     * Método para imprimir um documento
     * 
     * @param document O documento a ser impresso
     */
    public void printJob(Object document) {
        String name = Thread.currentThread().getName();
        try {
            // Adquire uma permissão do semáforo
            semaphore.acquire();
            
            // Exibe a hora em que a impressão começou
            System.out.println(name + " :: at : " + sdf.format(new Date()));

            // Simula o tempo de impressão
            long duration = (long) (Math.random() * 10);
            System.out.println(name + ": PrintQueue: Printing a Job during " + duration + " seconds");

            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Exibe a hora em que a impressão terminou
            System.out.println(name + " :: at : " + sdf.format(new Date()) + "\r\n");
            // Libera a permissão do semáforo
            semaphore.release();
        }
    }
}