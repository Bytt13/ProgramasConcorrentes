package Semaforo;

public class Job implements Runnable {
    private PrintQueue printQueue;

    // Construtor que recebe uma instância de PrintQueue
    public Job(PrintQueue printQueue) {
        this.printQueue = printQueue;
    }

    @Override
    public void run() {
        // Chama o método printJob da fila de impressão
        printQueue.printJob(new Object());
    }
}
