package ReadWrite;

import java.util.Date;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class PricesInfo {

    // Variáveis para armazenar os preços
    private double price1;
    private double price2;

    // ReadWriteLock para gerenciar o acesso concorrente
    private ReadWriteLock lock;

    public PricesInfo() {
        // Inicializa os preços
        price1 = 1.0;
        price2 = 2.0;
        
        // Inicializa o ReadWriteLock
        lock = new ReentrantReadWriteLock();
    }
    
    // Método para obter o valor de price1
    public double getPrice1() {
        // Adquire o bloqueio de leitura
        lock.readLock().lock();
        
        // Simula um atraso e imprime uma mensagem
        System.out.println("price1 read lock adquirido =====>");	
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        double value = price1;
        System.out.println("price1 read lock liberado <=====");
        
        // Libera o bloqueio de leitura
        lock.readLock().unlock();
        
        return value;
    }
    
    // Método para obter o valor de price2
    public double getPrice2() {
        // Adquire o bloqueio de leitura
        lock.readLock().lock();
        
        System.out.println("price2 read lock adquirido =====>");	// Simula um atraso e imprime uma mensagem
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        double value = price2;
        System.out.println("price2 read lock liberado <=====");
        
        // Libera o bloqueio de leitura
        lock.readLock().unlock();
        
        return value;
    }
    
    // Método para definir novos valores para price1 e price2
    public void setPrices(double price1, double price2) {
        // Adquire o bloqueio de escrita
        lock.writeLock().lock();
        System.out.println("Write lock adquirido em " + new Date());
        try {
            Thread.sleep(2 * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Atualiza os preços
        this.price1 = price1;
        this.price2 = price2;
        
        System.out.println("Write lock liberado em " + new Date());
        // Libera o bloqueio de escrita
        lock.writeLock().unlock();
    }
}
