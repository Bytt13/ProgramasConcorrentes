package ReadWrite;

public class Main {

    public static void main(String[] args) {
        // Cria uma instância de PricesInfo que será compartilhada entre leitores e escritor
        PricesInfo pricesInfo = new PricesInfo();

        // Cria arrays para armazenar objetos Reader e suas respectivas threads
        Reader readers[] = new Reader[5];
        Thread threadsReader[] = new Thread[5];

        // Inicializa os objetos Reader e suas threads
        for (int i = 0; i < 5; i++) {
            readers[i] = new Reader(pricesInfo);
            threadsReader[i] = new Thread(readers[i]);
        }

        // Cria um objeto Writer e sua respectiva thread
        Writer writer = new Writer(pricesInfo);
        Thread threadWriter = new Thread(writer);

        // Inicia todas as threads dos leitores
        for (int i = 0; i < 5; i++) {
            threadsReader[i].start();
        }

        // Inicia a thread do escritor
        threadWriter.start();
    }
}