package ReadWrite;

public class Reader implements Runnable {

    private PricesInfo pricesInfo;

    // Construtor que recebe uma instância de PricesInfo
    public Reader(PricesInfo pricesInfo) {
        this.pricesInfo = pricesInfo;
    }

    @Override
    public void run() {
        // Executa a leitura dos preços 10 vezes
        for (int i = 0; i < 10; i++) {
            System.out.printf("%s: Price 1: %f\n", Thread.currentThread().getName(), pricesInfo.getPrice1());
            System.out.printf("%s: Price 2: %f\n", Thread.currentThread().getName(), pricesInfo.getPrice2());
        }
    }

}
