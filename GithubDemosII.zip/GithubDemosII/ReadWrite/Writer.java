package ReadWrite;

public class Writer implements Runnable {

    private PricesInfo pricesInfo;

    // Construtor que recebe uma instância de PricesInfo
    public Writer(PricesInfo pricesInfo) {
        this.pricesInfo = pricesInfo;
    }

    @Override
    public void run() {
        // Executa a modificação dos preços 3 vezes
        for (int i = 0; i < 3; i++) {
            System.out.printf("Writer: Tentativa de modificar os preços.\n");
            pricesInfo.setPrices(Math.random() * 10, Math.random() * 8);
            System.out.printf("Writer: Os preços foram modificados.\n");
            try {
                // Pausa a execução por 2 milissegundos
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}