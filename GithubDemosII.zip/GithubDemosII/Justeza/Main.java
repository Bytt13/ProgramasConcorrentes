package Justeza;

public class Main {
    public static void main(String[] args) {
        // Cria uma instância de PrintQueue
        PrintQueue printQueue = new PrintQueue();

        // Cria um array de threads
        Thread thread[] = new Thread[10];
        for (int i = 0; i < 10; i++) {
            // Inicializa cada thread com um novo Job que usa a mesma PrintQueue
            thread[i] = new Thread(new Job(printQueue), "Thread " + i);
        }

        // Inicia cada thread
        for (int i = 0; i < 10; i++) {
            thread[i].start();
            try {
                // Pausa a execução por 100 milissegundos entre o início de cada thread
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
}