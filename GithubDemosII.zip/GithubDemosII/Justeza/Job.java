package Justeza;

public class Job implements Runnable {

    private PrintQueue printQueue;

    // Construtor que recebe uma instância de PrintQueue
    public Job(PrintQueue printQueue) {
        this.printQueue = printQueue;
    }

    @Override
    public void run() {
        // Imprime uma mensagem indicando que o trabalho de impressão vai começar
        System.out.println(Thread.currentThread().getName() + ": Going to print a job");
        // Chama o método printJob da fila de impressão
        printQueue.printJob(new Object());
        // Imprime uma mensagem indicando que o documento foi impresso
        System.out.println(Thread.currentThread().getName() + ": The document has been printed");
    }

}