package Justeza;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class PrintQueue {
    /**
     * Lock para gerenciar o acesso à fila de impressão
     */
    private final Lock queueLock = new ReentrantLock(false);
//	private final Lock queueLock = new ReentrantLock(false);

    public void printJob(Object document) {
        // Adquire o lock antes de iniciar a impressão
        queueLock.lock();

        try {
            // Simula o tempo de impressão
            Long duration = (long) (Math.random() * 10000);
            System.out.println(Thread.currentThread().getName() + ": PrintQueue: Imprimindo um trabalho durante " + (duration / 1000) + " segundos no primeiro bloco de código");
            
//			System.out.println(Thread.currentThread().getName() + ": PrintQueue: Imprimindo um trabalho durante " + (duration / 1000) + " segundos");
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Libera o lock após a impressão
            queueLock.unlock();
        }

        // Adquire o lock novamente antes de iniciar a próxima impressão
        queueLock.lock();
        try {
            // Simula o tempo de impressão
            Long duration = (long) (Math.random() * 10000);
            System.out.println(Thread.currentThread().getName() + ": PrintQueue: Imprimindo um trabalho durante " + (duration / 1000) + " segundos no segundo bloco de código");
            
//			System.out.println(Thread.currentThread().getName() + ": PrintQueue: Imprimindo um trabalho durante " + (duration / 1000) + " segundos");
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Libera o lock após a impressão
            queueLock.unlock();
        }
    }

}
