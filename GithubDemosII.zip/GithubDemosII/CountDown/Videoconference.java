package CountDown;

import java.util.concurrent.CountDownLatch;

public class Videoconference implements Runnable {

    private final CountDownLatch controller;

    /**
     * Construtor que inicializa o CountDownLatch com o número de participantes
     * 
     * @param number Número de participantes
     */
    public Videoconference(int number) {
        controller = new CountDownLatch(number);
    }

    /**
     * Método que notifica a chegada de um participante
     * 
     * @param name Nome do participante
     */
    public void arrive(String name) {
        System.out.println(name + " has arrived.");
        // Decrementa o contador do CountDownLatch
        controller.countDown();
        System.out.println("VideoConference: Waiting for " + controller.getCount() + " participants.");
    }

    @Override
    public void run() {
        System.out.println("VideoConference: Initialization: " + controller.getCount() + " participants.\n");

        try {
            // Aguarda até que todos os participantes tenham chegado
            controller.await();

            // Todos os participantes chegaram
            System.out.println("\nVideoConference: All the participants have come");
            System.out.println("VideoConference: Let's start...");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}