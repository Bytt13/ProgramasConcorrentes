package CountDown;

import java.util.concurrent.TimeUnit;

public class Participant implements Runnable {
    private Videoconference conference;
    private String name;

    // Construtor que recebe uma instância de Videoconference e o nome do participante
    public Participant(Videoconference conference, String name) {
        this.conference = conference;
        this.name = name;
    }

    @Override
    public void run() {
        // Simula o tempo que o participante leva para chegar à videoconferência
        Long duration = (long) (Math.random() * 10);
        
        try {
            // Pausa a execução por um tempo aleatório
            TimeUnit.SECONDS.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Notifica a videoconferência que o participante chegou
        conference.arrive(name);
    }
}
