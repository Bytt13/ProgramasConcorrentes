package CountDown;

public class Main {
    public static void main(String[] args) {
        // Cria uma instância de Videoconference com 10 participantes
        Videoconference conference = new Videoconference(10);

        // Cria e inicia a thread da videoconferência
        Thread threadConference = new Thread(conference);
        threadConference.start();

        // Cria e inicia as threads dos participantes
        for (int i = 0; i < 10; i++) {
            Participant p = new Participant(conference, "Participant " + i);
            Thread t = new Thread(p);
            t.start();
        }
    }
}