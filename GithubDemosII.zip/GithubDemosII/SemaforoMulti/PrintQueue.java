package SemaforoMulti;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class PrintQueue {
    /**
     * Semáforo para gerenciar o acesso à fila de impressão
     */
    private Semaphore semaphore;

    /**
     * Array para indicar quais impressoras estão livres
     */
    private boolean freePrinters[];

    /**
     * Lock para gerenciar o acesso ao array de impressoras livres
     */
    private Lock lockPrinters;

    // Formato de data para exibir o tempo
    private final SimpleDateFormat sdf = new SimpleDateFormat("mm:ss.SSS");

    public PrintQueue() {
        // Inicializa o semáforo com 3 permissões
        semaphore = new Semaphore(3);
        freePrinters = new boolean[3];
        for (int i = 0; i < 3; i++) {
            freePrinters[i] = true;
        }
        lockPrinters = new ReentrantLock();
    }

    /**
     * Método para imprimir um documento
     * 
     * @param document O documento a ser impresso
     */
    public void printJob(Object document) {
        String name = Thread.currentThread().getName();
        try {
            // Adquire uma permissão do semáforo
            semaphore.acquire();

            // Exibe a hora em que a impressão começou
            System.out.println(name + "  at : " + sdf.format(new Date()));

            // Obtém o número da impressora livre
            int assignedPrinter = getPrinter();

            // Simula o tempo de impressão
            Long duration = (long) (Math.random() * 10);
            System.out.println(name + ": PrintQueue: Printing a Job in Printer " + assignedPrinter + " during " + duration + " seconds");
            TimeUnit.SECONDS.sleep(duration);

            // Marca a impressora como livre
            freePrinters[assignedPrinter] = true;
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Exibe a hora em que a impressão terminou
            System.out.println(name + " finished printing  at : " + sdf.format(new Date()) + "\r\n");

            // Libera a permissão do semáforo
            semaphore.release();
        }
    }

    /**
     * Método para obter o número da impressora livre
     * 
     * @return O número da impressora livre
     */
    private int getPrinter() {
        int ret = -1;

        try {
            // Adquire o lock para acessar o array de impressoras livres
            lockPrinters.lock();

            for (int i = 0; i < freePrinters.length; i++) {
                if (freePrinters[i]) {
                    ret = i;
                    freePrinters[i] = false;
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Libera o lock após acessar o array de impressoras livres
            lockPrinters.unlock();
        }

        return ret;
    }
}
