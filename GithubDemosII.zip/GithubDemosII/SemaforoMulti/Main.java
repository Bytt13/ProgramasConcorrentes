package SemaforoMulti;

public class Main {

    public static void main(String args[]) {

        // Cria uma instância de PrintQueue
        PrintQueue printQueue = new PrintQueue();

        // Cria um array de threads
        Thread thread[] = new Thread[12];
        for (int i = 0; i < 12; i++) {
            // Inicializa cada thread com um novo Job que usa a mesma PrintQueue
            thread[i] = new Thread(new Job(printQueue), "Thread " + i);
        }

        // Inicia cada thread
        for (int i = 0; i < 12; i++) {
            thread[i].start();
        }
    }

}