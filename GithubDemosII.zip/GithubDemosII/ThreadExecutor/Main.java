package ThreadExecutor;

public class Main {
    public static void main(String[] args) {
        // Cria uma instância do servidor
        Server server = new Server();

        // Cria e executa 100 tarefas
        for (int i = 0; i < 100; i++) {
            Task task = new Task("Task " + i);
            server.executeTask(task);
        }

        // Finaliza o servidor
        server.endServer();
    }
}