package DemoPhaser;

import java.util.concurrent.Phaser;

public class Main {
    public static void main(String[] args) {
        // Cria uma instância de Phaser com 3 participantes
        Phaser phaser = new Phaser(3);

        // Cria instâncias de FileSearch para diferentes diretórios
        FileSearch system = new FileSearch("C:\\Windows", "log", phaser);
        FileSearch apps = new FileSearch("C:\\Program Files", "log", phaser);
        FileSearch documents = new FileSearch("C:\\Documents And Settings", "log", phaser);

        // Cria e inicia as threads para cada FileSearch
        Thread systemThread = new Thread(system, "System");
        systemThread.start();

        Thread appsThread = new Thread(apps, "Apps");
        appsThread.start();

        Thread documentsThread = new Thread(documents, "Documents");
        documentsThread.start();

        // Aguarda a conclusão de todas as threads
        try {
            systemThread.join();
            appsThread.join();
            documentsThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Verifica se o Phaser foi terminado
        System.out.println("Terminated: " + phaser.isTerminated());
    }
}
