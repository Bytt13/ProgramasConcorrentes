package GithubDemos.Lock;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * A classe PrintQueue simula uma fila de impressão usando um Lock para controlar o acesso.
 */
public class PrintQueue {
    private final Lock queueLock = new ReentrantLock();
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss:SSS");

    /**
     * Simula a impressão de um documento.
     * 
     * @param document O documento a ser impresso.
     */
    public void printJob(Object document){
        queueLock.lock();

        System.out.println(":: at : " + sdf.format(new Date()));

        try {
            Long duration = (long) (Math.random() * 10000);
            System.out.println(Thread.currentThread().getName() + " PrintQueue: Printing a Job during " + (duration/1000) + 
            " seconds :: Time - " + sdf.format(new Date()));
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            System.out.printf("%s The document has been printed\n", Thread.currentThread().getName());
            queueLock.unlock();
        }
    }
}
