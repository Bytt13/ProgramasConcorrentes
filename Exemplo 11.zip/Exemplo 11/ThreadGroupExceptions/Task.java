package GithubDemos.ThreadGroupExceptions;

import java.util.Random;

/**
 * A classe Task implementa a interface Runnable e simula uma tarefa que pode gerar uma exceção.
 */
public class Task implements Runnable{

    @Override
    public void run(){
        int result;
        Random random = new Random(Thread.currentThread().getId());

        while(true){
            // Gera um valor aleatório e tenta dividir 1000 por esse valor
            result = 1000 / ((int)(random.nextDouble() * 1000));
            System.out.println(Thread.currentThread().getId() + " : " + result);

            // Verifica se a thread foi interrompida
            if(Thread.currentThread().isInterrupted()){
                System.out.printf(Thread.currentThread().getId() + " : The Thread has been interrupted");
                return;
            }
        }
    }
}
