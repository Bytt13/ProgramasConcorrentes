package GithubDemos.ThreadGroupExceptions;

/**
 * A classe MyThreadGroup estende a classe ThreadGroup e lida com exceções não capturadas em threads do grupo.
 */
public class MyThreadGroup extends ThreadGroup {

    /**
     * Construtor da classe MyThreadGroup.
     * 
     * @param name O nome do grupo de threads.
     */
    public MyThreadGroup(String name) {
        super(name);
    }

    /**
     * O método uncaughtException é chamado quando uma thread do grupo termina devido a uma exceção não capturada.
     * 
     * @param t A thread que gerou a exceção.
     * @param e A exceção não capturada.
     */
    @Override
    public void uncaughtException(Thread t, Throwable e){
        System.out.println("The thread " + t.getId() + " has thrown an exception");
        e.printStackTrace(System.out);
        System.out.println("Finalizando o resto das threads");
        interrupt();
    }
}